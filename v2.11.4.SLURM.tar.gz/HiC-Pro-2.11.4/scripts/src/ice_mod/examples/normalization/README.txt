.. _normalization_examples:

Normalization
-------------

Examples concerning the :mod:`iced.normalization` module.
