.. _filter:

=============
Filtering
=============

The :mod:`filter` submodule contains utilities for filtering the contact count
matrix prior to normalizing.


.. currentmodule:: iced.filter
